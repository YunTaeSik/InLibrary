package com.example.sky87.inlibrary.adapter;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.sky87.inlibrary.R;


/**
 * Created by User on 2016-03-08.
 */
public class GridViewAdapter extends CursorAdapter {

    private Context c;
    TextView textview;
    ImageView grid_item_image;
    LinearLayout grid_item_layout;

    public GridViewAdapter(Context c, Cursor cursor) {
        super(c, cursor);
        this.c = c;
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View v = layoutInflater.inflate(R.layout.grid_item, parent, false);
        return v;
    }

    @Override
    public void bindView(View v, Context context, final Cursor cursor) {
        textview = (TextView) v.findViewById(R.id.grid_item_text);
        grid_item_image = (ImageView) v.findViewById(R.id.grid_item_image);
        grid_item_layout = (LinearLayout) v.findViewById(R.id.grid_item_layout);
        textview.setText(cursor.getString(1));

    }

    @Override
    public void changeCursor(Cursor cursor) {
        super.changeCursor(cursor);
    }


}
