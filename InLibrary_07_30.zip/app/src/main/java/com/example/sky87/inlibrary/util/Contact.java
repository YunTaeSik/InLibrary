package com.example.sky87.inlibrary.util;

/**
 * Created by sky87 on 2016-06-23.
 */
public class Contact {
    public static String VIST_LIST = "VIST_LIST";  //방문리스트
    public static String ACTION_LIST = "ACTION_LIST";  //활동 리스트
    public static String ROUTE_LIST = "ROUTE_LIST";
    public static String USER = "USER";
    public static String Recipient = "sky877kr@naver.com";
}
